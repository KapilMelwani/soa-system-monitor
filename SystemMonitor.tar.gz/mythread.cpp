#include "mythread.h"

mythread::mythread()
{
}

void mythread::run(void)
{

}
