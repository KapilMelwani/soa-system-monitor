#include "systemmonitorworker.h"

void SystemMonitorWorker::doHardware()
{

}

